﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;


static public class Color32Ex
{
    public static Color32 FromArgb(int argb)
    {
        return new Color32((byte)(argb >> 16 & 255), (byte)(argb >> 8 & 255), (byte)(argb >> 0 & 255), (byte)(argb >> 24 & 255));
    }

    public static int ToArgb(this Color32 color)
    {
        return color.a << 24 | color.r << 16 | color.g << 8 | color.b;
    }

    public static float GetHue(this Color32 color)
    {
        int r = (int)color.r;
        int g = (int)color.g;
        int b = (int)color.b;

        byte b2 = (byte)Math.Min(r, Math.Min(g, b));
        byte b3 = (byte)Math.Max(r, Math.Max(g, b));
        if (b3 == b2)
        {
            return 0f;
        }
        float num = (float)(b3 - b2);
        float num2 = (float)((int)b3 - r) / num;
        float num3 = (float)((int)b3 - g) / num;
        float num4 = (float)((int)b3 - b) / num;
        float num5 = 0f;
        if (r == (int)b3)
        {
            num5 = 60f * (6f + num4 - num3);
        }
        if (g == (int)b3)
        {
            num5 = 60f * (2f + num2 - num4);
        }
        if (b == (int)b3)
        {
            num5 = 60f * (4f + num3 - num2);
        }
        if (num5 > 360f)
        {
            num5 -= 360f;
        }
        return num5;
    }

    public static float GetSaturation(this Color32 color)
    {
        byte b = Math.Min(color.r, Math.Min(color.g, color.b));
        byte b2 = Math.Max(color.r, Math.Max(color.g, color.b));
        if (b2 == b)
        {
            return 0f;
        }
        int num = (int)(b2 + b);
        if (num > 255)
        {
            num = 510 - num;
        }
        return (float)(b2 - b) / (float)num;
    }

    public static float GetBrightness(this Color32 color)
    {
        byte b = Math.Min(color.r, Math.Min(color.g, color.b));
        byte b2 = Math.Max(color.r, Math.Max(color.g, color.b));
        return (float)(b2 + b) / 510f;
    }

}
